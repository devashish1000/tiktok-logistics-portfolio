# Dev Neupane — Logistics portfolio

Separate local Next.js static portfolio for financial operations and logistics solution delivery. Source facts are user-confirmed, not independently audited. The settlement work sample is explicitly hypothetical.

## Local preview

Install dependencies with pnpm, then `pnpm build` and `PORT=4175 pnpm start`.
Open http://127.0.0.1:4175/tiktok-logistics-portfolio/ .

Both logistics PDFs are in public/ and linked from the page. Source achievements: src/data/content.ts. Hypothetical exercise: src/data/casework.ts.

## Publication status

Unpublished. No remote configured. The manual-only GitHub Pages workflow is restricted to devashish1000/tiktok-logistics-portfolio; this repository has not been created or pushed. Original github.io and the PM portfolio are untouched.

The requested TikTok role ID7629472855006513413 currently shows Position no longer available at its official referral link, checked September14,2026. The package is reusable for relevant opportunities, not evidence of an active application.
