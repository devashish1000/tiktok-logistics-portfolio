import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  icons: { icon: "/tiktok-logistics-portfolio/favicon.svg" },
  title: "Dev Neupane — Financial Operations & Solution Delivery",
  description: "Selected work in financial analysis, reporting controls, data quality, vendor readiness, and solution delivery.",
  metadataBase: new URL("https://devashish1000.github.io/tiktok-logistics-portfolio/"),
  alternates: { canonical: "https://devashish1000.github.io/tiktok-logistics-portfolio/" },
  openGraph: {
    title: "Dev Neupane — Financial Operations & Solution Delivery",
    description: "Clear inputs. Reliable controls. Better cost decisions.",
    type: "website",
    url: "https://devashish1000.github.io/tiktok-logistics-portfolio/",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><a className="skip-link" href="#main">Skip to content</a>{children}</body></html>;
}
