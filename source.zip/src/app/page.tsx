import Image from "next/image";
import { ArrowDown, ArrowRight, ArrowUpRight, Plus } from "@phosphor-icons/react/dist/ssr";
import { Header } from "@/components/Header";
import { SettlementSample } from "@/components/Casework";
import { stories, experience, headwell, recruiterIntro } from "@/data/content";

const base = "/tiktok-logistics-portfolio";
const resume = `${base}/Dev_Neupane_TikTok_Logistics_Resume.pdf`;

export default function Home() {
  return <><Header /><main id="main" tabIndex={-1}>
    <section className="hero shell" aria-labelledby="hero-title">
      <div className="hero-copy">
        <p className="hero-role">Financial operations · Solution delivery</p>
        <h1 id="hero-title">Clear inputs.<br /><em>Reliable controls.</em><br />Better cost decisions.</h1>
        <p className="hero-intro">{recruiterIntro}</p>
        <div className="hero-actions"><a className="button" href="#work">Explore selected work <ArrowRight size={22} aria-hidden="true" /></a><a className="text-link" href={resume} download>Download résumé <ArrowDown size={19} aria-hidden="true" /></a><a className="hero-profile" href="https://linkedin.com/in/devashishn" target="_blank" rel="noopener noreferrer">LinkedIn <ArrowUpRight size={16} aria-hidden="true" /></a></div>
      </div>
      <figure className="portrait"><Image src={`${base}/dev-neupane-headshot.webp`} width={640} height={800} alt="Dev Neupane" priority sizes="(max-width: 700px) 48vw, 28vw" /><figcaption>Financial analysis · Data quality · Delivery</figcaption></figure>
    </section>

    <section className="impact shell" aria-labelledby="impact-title">
      <div className="section-label-row"><h2 id="impact-title" className="small-label">Selected impact</h2><span>Invoice reconciliation · Exception handling · Data quality</span></div>
      <div className="impact-grid">
        <div><strong>100+</strong><p>Cost centers · Southwest Airlines</p></div>
        <div><strong>95%</strong><p>Disputed invoice items resolved within ten business days · Allen &amp; Overy</p></div>
        <div><strong>40%</strong><p>Fewer incomplete or inconsistent<br className="desktop-break" /> submissions · NYC DOE</p></div>
      </div>
    </section>

    <section id="work" className="work shell" tabIndex={-1} aria-labelledby="work-title">
      <div className="section-heading"><h2 id="work-title">Selected work.</h2><p>Financial analysis, controls, and delivery.</p></div>
      <div className="work-list">{stories.map((story, i) => <article className="story" key={story.title}>
        <div className="story-source"><span>{String(i+1).padStart(2,"0")}</span><p>{story.company}</p></div>
        <div className="story-content"><h3>{story.title}.</h3><p>{story.summary}</p></div>
        <div className="story-metric"><strong className={i === 0 ? "wide-metric" : undefined}>{story.metric}</strong><p>{story.metricLabel}</p></div>
        <details className="story-details"><summary>{story.disclosure} <Plus size={17} aria-hidden="true" /></summary>{<div className="expanded-story"><dl><div><dt>Scope</dt><dd>{story.scope}</dd></div><div><dt>My contribution</dt><dd>{story.contribution}</dd></div><div><dt>Outcome</dt><dd>{story.outcome}</dd></div></dl></div>}</details>
      </article>)}</div>
      <div className="program-context"><h3>Requirements that teams can deliver.</h3><div><article><h4>Acceptance and validation</h4><p>At Bellevue University, I delivered three application and data enhancements in eight weeks. I aligned six stakeholders on requirements and acceptance criteria, and led acceptance testing across twelve user workflows.</p></article><article><h4>Cross-functional execution</h4><p>At LinkedIn, I owned eight initiatives across Trust &amp; Safety Operations, Policy, Engineering, and Data Science. Coordinating requirements, dependencies, and readiness helped deliver 95% of milestones on time. Standardized sign-off checklists reduced post-launch requirement gaps from ten to four per quarter.</p></article></div></div>
    </section>

    <section id="project" className="project" aria-labelledby="project-title"><div className="shell project-grid">
      <div><p className="small-label">Project / HeadWell</p><h2 id="project-title">From requirements<br />to release.</h2><p className="project-role">{headwell.title} · {headwell.dates}</p><p className="project-intro">I owned the roadmap and delivery from concept to TestFlight, coordinating product and engineering partners.</p><p className="project-ai">Automated freshness alerts reduced stale-feed detection from 24 hours to two hours for health, sleep, and environmental signals.</p>
        <details className="story-details project-details"><summary>Read the HeadWell project summary <Plus size={18} aria-hidden="true" /></summary><div className="expanded-story"><dl><div><dt>Delivery</dt><dd>{headwell.scope}</dd></div><div><dt>Data quality</dt><dd>{headwell.quality}</dd></div><div><dt>Feedback prioritization</dt><dd>{headwell.feedback}</dd></div></dl><p className="project-note">Project · Initial release on TestFlight</p></div></details>
      </div>
      <div className="project-metrics"><div><strong>10 <span>weeks</span></strong><p>Initial TestFlight release</p></div><div><strong>95<span>%</span></strong><p>Data completeness across connected feeds</p></div></div>
    </div></section>

    <SettlementSample />

    <section id="experience" className="experience shell" tabIndex={-1} aria-labelledby="experience-title">
      <div className="experience-heading"><h2 id="experience-title">Experience.</h2><p>Financial analysis and delivery across technology, operations, and software systems.</p><a className="experience-work-link" href="#work">Explore selected work <ArrowUpRight size={17} aria-hidden="true" /></a><a className="text-link" href={resume} download>Full résumé <ArrowDown size={18} aria-hidden="true" /></a></div>
      <div className="experience-list">{experience.map(item => <article key={item.company}><div className="experience-top"><h3>{item.company}</h3><p className="dates">{item.dates}</p></div><p className="role">{item.role}</p><p className="achievement">{item.achievement}</p><details className="experience-detail"><summary>Read supporting detail</summary><p className="achievement">{item.detail}</p></details></article>)}
        <div className="education"><h3>University of Nebraska Omaha</h3><p>MBA, Supply Chain &amp; Logistics · 2025<br />B.S., Management Information Systems · 2019</p><span>Highest Distinction · Both degrees</span></div>
      </div>
    </section>

    <footer id="contact" className="contact shell" tabIndex={-1}><div className="contact-main"><h2>Let’s discuss<br />financial operations.</h2><div className="contact-details"><p>Financial operations · Solution delivery<br />Open to relocation</p><a className="email" href="mailto:devashish1000@gmail.com">devashish1000@gmail.com <ArrowUpRight size={23} aria-hidden="true" /></a><div className="contact-links"><a href="https://linkedin.com/in/devashishn" target="_blank" rel="noopener noreferrer">LinkedIn <ArrowUpRight size={15} aria-hidden="true" /></a><a href="https://github.com/devashish1000" target="_blank" rel="noopener noreferrer">GitHub <ArrowUpRight size={15} aria-hidden="true" /></a><a href={resume} download>Résumé <ArrowDown size={15} aria-hidden="true" /></a><a href={`${base}/Dev_Neupane_TikTok_Logistics_Cover_Letter.pdf`} download>Cover letter <ArrowDown size={15} aria-hidden="true" /></a></div></div></div><div className="footer-bottom"><span>Dev Neupane © 2026</span><a href="#top">Back to top <ArrowUpRight size={16} aria-hidden="true" /></a></div></footer>
  </main></>;
}
