import { Plus } from "@phosphor-icons/react/dist/ssr";
import { settlementSample, type CasePoint } from "@/data/casework";
function Points({ items }: { items: CasePoint[] }) {
  return <dl className="brief-points">{items.map(item => <div key={item.title}><dt>{item.title}</dt><dd>{item.detail}</dd></div>)}</dl>;
}
export function FinancialCase() {
  return <div className="case-brief">
    <div className="brief-opening"><p className="small-label">Financial controls brief / Allen &amp; Overy</p><h4>Consistent inputs. Visible exceptions.</h4><p>I automated monthly budget and project reporting across ten cost centers.</p></div>
    <div className="brief-columns"><div><h5>My contribution</h5><p>I standardized financial inputs and exception checks within the reporting process and reduced preparation time.</p><h5>Related vendor-delivery work</h5><p>Separately, I led readiness across eight vendors and two offices serving 750 employees. I tracked 85 critical milestones, dependencies, risks, and acceptance criteria; 97% of milestones finished on schedule.</p></div><div><h5>Reporting results</h5><ul className="brief-results"><li><strong>50%</strong><span>Less preparation time</span></li><li><strong>40 hours</strong><span>Saved each month</span></li></ul><p className="brief-source-note">These results describe budget and project reporting. The settlement exercise below is a separate, hypothetical proposal.</p></div></div>
  </div>;
}
export function SettlementSample() {
  return <section className="live-sample shell" id="settlement-sample" tabIndex={-1} aria-labelledby="sample-title">
    <div className="sample-heading"><div><p className="small-label">Hypothetical work sample</p><h2 id="sample-title">When a billed charge<br />does not match.</h2></div><div className="sample-disclosure"><strong>Independent illustrative analysis</strong><p>A proposed approach, not past employment or TikTok internal processes. No employer financial outcomes are claimed.</p></div></div>
    <div className="sample-scenario"><h3>The scenario</h3><p>{settlementSample.scenario}</p></div>
    <div className="sample-principle"><span>My starting point</span><p>Trace the charge to the source. Resolve the exception before treating it as a confirmed recovery.</p></div>
    <section className="executed-sample" aria-labelledby="executed-title"><p className="small-label">Executed synthetic demonstration</p><h3 id="executed-title">Six records. Every difference accounted for.</h3><p>A reproducible Python example tests a rule change, duplicate invoice line, missing source, credit and normal matches. All amounts and review decisions are fictional USD examples.</p><dl className="sample-results"><div><dt>Billed total</dt><dd>$58</dd></div><div><dt>Known expected + variance + unresolved</dt><dd>$36 + $14 + $8</dd></div><div><dt>Disputed / approved / posted</dt><dd>$14 / $2 / $2</dd></div><div><dt>Automated checks</dt><dd>Passed</dd></div></dl><p>Workflow stages are cumulative, not additive. The $8 missing-source line has no assumed variance. The $2 posted credit is a fictional ledger decision, not a business recovery.</p><div className="sample-downloads">{["complete-analysis.zip","decision-brief.md","results.csv","results.json","reproduce.py","invoices.csv","events.csv","rules.csv","expected.json"].map(file=><a key={file} href={`/tiktok-logistics-portfolio/sample/${file}`} download>{file === "complete-analysis.zip" ? "Download complete analysis" : file}</a>)}</div><p>Run the downloaded script and input files together with Python 3. Read the decision brief for definitions and limitations.</p></section>
    <details className="sample-details"><summary>Read the settlement solution brief <Plus size={20} aria-hidden="true" /></summary><div className="sample-expanded">
      <section><h3>Define the rule before automating it.</h3><Points items={settlementSample.foundations} /></section>
      <section><h3>From variance to reviewed decision.</h3><ol className="decision-steps">{settlementSample.steps.map(point => <li key={point.title}><h4>{point.title}</h4><p>{point.detail}</p></li>)}</ol></section>
      <section><h3>Acceptance before scale.</h3><Points items={settlementSample.acceptance} /></section>
      <section><h3>Measure accuracy, time, and money separately.</h3><Points items={settlementSample.metrics} /></section>
      <p className="sample-deliverable">The proposed deliverable: a versioned rule specification, test cases with expected results, an exception register, and an approval trail from source evidence to final disposition.</p>
      <p className="brief-source-note">Independent hypothetical sample · No platform data, executed financial actions, or achieved outcomes</p>
    </div></details>
  </section>;
}
