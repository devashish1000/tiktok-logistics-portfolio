"use client";

import { useRef, useState } from "react";
import { ArrowDown, List, X } from "@phosphor-icons/react";

export const resumeUrl = "/tiktok-logistics-portfolio/Dev_Neupane_TikTok_Logistics_Resume.pdf";

export function Header() {
  const [open, setOpen] = useState(false);
  const toggle = useRef<HTMLButtonElement>(null);
  const followAnchor = (id: string) => {
    setOpen(false);
    requestAnimationFrame(() => document.getElementById(id)?.focus({ preventScroll: true }));
  };
  return <header className="site-header" id="top" tabIndex={-1} onKeyDown={(e) => {if(e.key === "Escape" && open) {setOpen(false); toggle.current?.focus();}}}><div className="shell header-inner">
    <a className="wordmark" href="#top" onClick={() => setOpen(false)}>Dev Neupane<span>FINANCIAL OPERATIONS &amp; SOLUTION DELIVERY</span></a>
    <button ref={toggle} className="menu-toggle" aria-label={open ? "Close navigation" : "Open navigation"} aria-expanded={open} aria-controls="navigation" onClick={() => setOpen(!open)}>{open ? <X size={24} aria-hidden="true" /> : <List size={24} aria-hidden="true" />}</button>
    <nav id="navigation" aria-label="Main navigation" className={open ? "navigation is-open" : "navigation"}>
      <a href="#work" onClick={() => followAnchor("work")}>Selected work</a>
      <a href="#settlement-sample" onClick={() => followAnchor("settlement-sample")}>Settlement sample</a>
      <a href="#experience" onClick={() => followAnchor("experience")}>Experience</a>
      <a href="#contact" onClick={() => followAnchor("contact")}>Contact</a>
      <a href={resumeUrl} download onClick={() => setOpen(false)}>Résumé <ArrowDown size={17} aria-hidden="true" /></a>
    </nav>
  </div></header>;
}
