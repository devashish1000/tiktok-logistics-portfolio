// Independently authored hypothetical exercise. No historical or employer outcomes.
export type CasePoint = { title: string; detail: string };
export const settlementSample = {
  scenario: "A logistics invoice line differs from the expected charge. The settlement team needs to establish the source of the difference, assign an accountable owner, and preserve a reviewable decision.",
  foundations: [
    { title: "Inputs", detail: "Shipment event, invoice line, approved contract or rate-card version, currency, unit and service period. I would first confirm which source is authoritative and how credits, taxes, surcharges and rounding are represented." },
    { title: "Controls", detail: "Validate completeness, match at line level, record differences, and require authorized review for adjustments. Version the applicable rule and its effective dates; make missing or ambiguous rules visible exceptions." },
    { title: "Decision", detail: "Separate data defects, timing differences and possible billing errors. No automatic payment or credit. Confirm the relevant contractual terms and approval owner before recommending a resolution." },
  ],
  steps: [
    { title: "Establish a complete comparison", detail: "Reconcile record counts and amounts between source extracts before matching. Check missing identifiers, duplicate invoice lines, units, currencies and service periods. Use agreed business keys rather than assuming one invoice equals one shipment." },
    { title: "Calculate and explain the variance", detail: "Apply the approved rule version to the relevant service event. Preserve the expected amount, billed amount, difference and calculation inputs. An unexplained difference is an exception, not proven leakage." },
    { title: "Route the exception", detail: "Assign data defects to the source owner, interpretation questions to the contract or policy owner, and possible billing errors to the settlement team for provider follow-up. Track evidence, owner, due date and review status." },
    { title: "Close with an audit trail", detail: "Record the reviewed decision, approval and any adjustment reference. Keep disputed, approved and actually posted amounts separate. Verify posting before describing an amount as recovered." },
  ],
  acceptance: [
    { title: "Test the rules", detail: "Agree expected results with business owners for normal, missing, duplicate, effective-date-boundary, credit and rounding cases. Re-running the same input must not create duplicate adjustments." },
    { title: "Reconcile the pilot", detail: "Use a limited parallel run. Compare counts and totals with the existing process, inspect unmatched items and sample the matches. Agree acceptance tolerances with the responsible owners; none are invented here." },
    { title: "Approve the launch", detail: "Document unresolved exceptions, access permissions, escalation paths and a rollback plan. Obtain business and technical acceptance before expanding scope or enabling financial actions." },
  ],
  metrics: [
    { title: "Completeness and match quality", detail: "Track missing and duplicate records against total received records; report matched eligible lines divided by all eligible lines. Review a sample of matches to detect false matches rather than treating match rate as accuracy." },
    { title: "Timeliness and accountability", detail: "Track open exception age, resolution time and items past the agreed due date, segmented by cause and owner. Keep contractual payment deadlines visible alongside unresolved disputes." },
    { title: "Financial result", detail: "Show identified variance, disputed amount, approved adjustment and posted recovery separately. Count savings or recoveries only under an agreed definition with evidence; this exercise claims none." },
  ],
};
