// All historical claims below are user-confirmed, not independently employment-verified.
export const recruiterIntro = "I connect vendor invoice reconciliation, financial-data controls, and solution delivery. At Allen & Overy, I resolved 95% of disputed invoice items within ten business days across three monthly billing cycles.";
export const stories = [
  {
    "company": "Southwest Airlines",
    "title": "Making cost data dependable",
    "summary": "I built SQL and SAP ERP/BW reporting across 100+ cost centers supporting an $8B+ portfolio, with standardized cost-code checks.",
    "metric": "2.0% \u2192 0.5%",
    "metricLabel": "unmatched records over three monthly reporting cycles",
    "disclosure": "Read the cost-data controls brief",
    "scope": "Cost-center reporting across 100+ cost centers supporting an $8B+ portfolio.",
    "contribution": "I standardized cost-code checks within the reporting work.",
    "outcome": "Unmatched records fell from 2.0% to 0.5% over three monthly reporting cycles."
  },
  {
    "company": "Allen & Overy",
    "title": "From disputed charge to resolution",
    "summary": "I reconciled vendor invoices against contract terms and investigated pricing and duplicate-charge exceptions.",
    "metric": "95%",
    "metricLabel": "of disputed items resolved within ten business days",
    "disclosure": "Read the invoice-reconciliation brief",
    "scope": "Vendor invoice reconciliation across three monthly billing cycles.",
    "contribution": "I reconciled invoices against contract terms and investigated pricing and duplicate-charge exceptions.",
    "outcome": "Resolved 95% of disputed items within ten business days across three monthly billing cycles."
  },
  {
    "company": "NYC Department of Education",
    "title": "Resolving recurring discrepancies",
    "summary": "I coordinated Finance, site administrators, and technical partners to resolve funding and project-data discrepancies.",
    "metric": "20%",
    "metricLabel": "fewer repeat discrepancies in the next reporting cycle",
    "disclosure": "Read the data-quality summary",
    "scope": "150 funding and project-data discrepancies.",
    "contribution": "I coordinated resolution across Finance, site administrators, and technical partners and used recurring-error reviews.",
    "outcome": "Closed 95% before deadline; recurring-error reviews reduced repeat discrepancies 20% in the next reporting cycle."
  }
];
export const experience = [
  {
    "company": "Bellevue University",
    "role": "Software Engineer",
    "dates": "Jul 2026 - Present",
    "achievement": "Delivered three application and data enhancements in eight weeks, aligning six stakeholders on requirements and acceptance criteria; reduced workflow processing time 25%.",
    "detail": "Delivered three application and data enhancements in eight weeks, aligning six stakeholders on requirements and acceptance criteria; reduced workflow processing time 25%. Automated validation across five data interfaces with exception logging and reconciliation checks, reducing manual verification 40% and saving ten staff hours weekly; exception routing cut median resolution from three to one business day. Led acceptance testing across twelve workflows, adding duplicate-record and missing-value cases for two recurring failure modes; resolved twenty defects before release and achieved 95% first-pass stakeholder acceptance."
  },
  {
    "company": "Southwest Airlines",
    "role": "Senior Performance Analyst, Corporate Analytics",
    "dates": "Apr 2023 - May 2024",
    "achievement": "Led twelve improvement initiatives with Finance, Commercial, and Technical partners, delivering $1.2M in annualized operating savings; introduced monthly benefit tracking to distinguish realized savings from forecast opportunities.",
    "detail": "Led twelve improvement initiatives with Finance, Commercial, and Technical partners, delivering $1.2M in annualized operating savings; introduced monthly benefit tracking to distinguish realized savings from forecast opportunities. Built SQL and SAP ERP/BW reporting across 100+ cost centers supporting an $8B+ portfolio; standardized cost-code checks reduced unmatched records from 2.0% to 0.5% over three monthly reporting cycles. Built operating reviews covering 15+ KPIs, cutting reporting time 60% and shortening performance-gap-to-action approval from ten to four business days."
  },
  {
    "company": "LinkedIn",
    "role": "Senior Business Analyst, Planning & Optimization",
    "dates": "Nov 2020 - Mar 2023",
    "achievement": "Built SQL and Python forecasts across 120+ planning streams for an $800M+ technology organization, achieving 94% forecast accuracy; identified capacity constraints eight weeks ahead to inform resource plans.",
    "detail": "Built SQL and Python forecasts across 120+ planning streams for an $800M+ technology organization, achieving 94% forecast accuracy; identified capacity constraints eight weeks ahead to inform resource plans. Evaluated resource and capacity scenarios that informed executive decisions contributing to a 3.2-percentage-point improvement in operating margin. Owned eight cross-functional initiatives, coordinating requirements, dependencies, and readiness to deliver 95% of milestones on time; standardized sign-off checklists reduced post-launch requirement gaps from ten to four per quarter."
  },
  {
    "company": "Allen & Overy",
    "role": "Business Analyst, Finance & Business Management",
    "dates": "Jan 2020 - Nov 2020",
    "achievement": "Reconciled vendor invoices against contract terms and resolved 95% of disputed items within ten business days across three monthly billing cycles.",
    "detail": "Evaluated four options for a $30M technology investment using ROI and total cost of ownership, identifying $2.4M in potential five-year cost avoidance to inform the investment decision. Automated monthly budget and project reporting across ten cost centers, standardizing financial inputs and exception checks; reduced preparation time 50% and saved forty hours monthly. Reconciled vendor invoices against contract terms, investigated pricing and duplicate-charge exceptions, and resolved 95% of disputed items within ten business days across three monthly billing cycles."
  },
  {
    "company": "NYC Department of Education",
    "role": "Finance & Budget Analyst, Business Management",
    "dates": "Aug 2019 - Dec 2019",
    "achievement": "Standardized capital-planning submissions and validation across 220+ sites, reducing incomplete or inconsistent inputs 40% and review-cycle time 25% in four months.",
    "detail": "Standardized capital-planning submissions and validation across 220+ sites, reducing incomplete or inconsistent inputs 40% and review-cycle time 25% in four months. Coordinated Finance, site administrators, and technical partners to resolve 150 funding and project-data discrepancies, closing 95% before deadline; recurring-error reviews reduced repeat discrepancies 20% in the next reporting cycle."
  }
];
export const headwell = {
  "title": "Co-Founder, Product & Analytics (Project)",
  "dates": "Dec 2025 - Present",
  "scope": "Translated 25 user interviews into twelve requirements and coordinated product and engineering delivery of the initial TestFlight release in ten weeks.",
  "quality": "Defined ten KPIs for health, sleep, and environmental data, with validation and seven-day forecasts, achieving 95% feed completeness; automated freshness alerts cut stale-feed detection from 24 to two hours.",
  "feedback": "Classified 500 feedback items using AI with human validation, reducing triage time 30% and shortening the feedback-to-decision cycle from seven to three days."
};
