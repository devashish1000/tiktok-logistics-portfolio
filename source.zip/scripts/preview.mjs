import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { resolve, extname, sep } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../out/", import.meta.url));
const base = "/tiktok-logistics-portfolio";
const mime = { ".html": "text/html; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".json": "application/json", ".txt": "text/plain", ".pdf": "application/pdf", ".png": "image/png", ".webp": "image/webp", ".svg": "image/svg+xml", ".csv": "text/csv", ".md": "text/plain; charset=utf-8", ".py": "text/plain; charset=utf-8", ".sql": "text/plain; charset=utf-8", ".zip": "application/zip", ".woff2": "font/woff2" };
const port = Number(process.env.PORT || 4173);

createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, "http://localhost").pathname);
    if (pathname === "/" || pathname === base) { res.writeHead(302, { Location: `${base}/` }).end(); return; }
    if (!pathname.startsWith(`${base}/`)) { res.writeHead(404).end("Not found"); return; }
    let file = resolve(root, `.${pathname.slice(base.length)}`);
    if (file !== resolve(root) && !file.startsWith(root.endsWith(sep) ? root : root + sep)) { res.writeHead(403).end(); return; }
    if ((await stat(file)).isDirectory()) file = resolve(file, "index.html");
    const data = await readFile(file);
    res.writeHead(200, { "Content-Type": mime[extname(file)] || "application/octet-stream", "Content-Length": data.length });
    res.end(req.method === "HEAD" ? undefined : data);
  } catch { res.writeHead(404).end("Not found"); }
}).listen(port, "127.0.0.1", () => console.log(`Preview: http://127.0.0.1:${port}${base}/`));
