"""Synthetic example only. Run python3 reproduce.py; no dependencies or network."""
import csv,json
from decimal import Decimal as D
from pathlib import Path
P=Path(__file__).resolve().parent

def read(name):
 with (P/name).open(newline='') as f:return list(csv.DictReader(f))
def run():
 events={r['event_id']:r for r in read('events.csv')};rules=read('rules.csv');rows=[];seen=set()
 for x in read('invoices.csv'):
  billed=D(x['billed']);event=events.get(x['event_id']);key=x['line_id'];duplicate=key in seen;seen.add(key)
  expected=None;version='';owner='';state='';variance=None
  if duplicate: expected=D('0');state='duplicate';owner='settlement reviewer'
  elif not event:state='missing source';owner='source-data owner'
  else:
   rule=next(r for r in rules if r['from_date']<=event['date']<r['until_date']);version=rule['version'];expected=D(rule['unit_rate'])*D(event['units']);state='match' if billed==expected else 'pricing exception';owner='none' if state=='match' else 'contract owner'
  if expected is not None:variance=billed-expected
  rows.append(dict(row=x['row'],line_id=key,event_id=x['event_id'],billed=str(billed),expected=None if expected is None else str(expected),variance=None if variance is None else str(variance),rule=version,routing=owner,disposition=state,disputed='0',approved='0',posted='0'))
 # Explicit fictional review ledger: stages are cumulative and not additive.
 for r in rows:
  if r['row']=='2':r.update(disputed='2',approved='2',posted='2',disposition='synthetic credit posted')
  if r['row']=='3':r.update(disputed='12',approved='0',posted='0',disposition='awaiting duplicate review')
 summary={'synthetic':True,'currency':'USD','input_rows':len(rows),'billed_total':str(sum(D(r['billed']) for r in rows)),'known_expected_total':str(sum(D(r['expected']) for r in rows if r['expected'] is not None)),'unresolved_source_billed':str(sum(D(r['billed']) for r in rows if r['expected'] is None)),'identified_variance':str(sum(D(r['variance']) for r in rows if r['variance'] is not None))}
 for k in ['disputed','approved','posted']:summary[k]=str(sum(D(r[k]) for r in rows))
 assert D(summary['billed_total'])==D(summary['known_expected_total'])+D(summary['identified_variance'])+D(summary['unresolved_source_billed'])
 expected=json.loads((P/'expected.json').read_text());assert summary==expected,(summary,expected)
 assert [r['rule'] for r in rows[:2]]==['v1','v2'] # boundary date uses new rule
 assert rows[2]['expected']=='0' and rows[3]['expected'] is None
 assert rows[4]['expected']=='-10' and rows[4]['variance']=='0'
 assert rows[5]['variance']=='0' # normal match with two units
 output={'summary':summary,'rows':rows};(P/'results.json').write_text(json.dumps(output,indent=2)+'\n')
 with (P/'results.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 print('PASS: totals, effective-date boundary, duplicate, missing source, credit, normal match; six synthetic rows. Deterministic output.')
 return output
if __name__=='__main__':run()
