# Synthetic reconciliation decision brief

Independent illustrative work, executed with Python standard library. All records, prices and review decisions are fictional. No TikTok/company data or achieved business savings.

## Decision
Proceed with review of the $12 duplicate. Hold the $8 missing-source line for source-data investigation. The separate $2 pricing difference has a fictional approved and posted credit in the demonstration ledger. Do not treat $14 identified variance as recovered cash.

## Reconciliation
Six billed rows total $58. Known expected charges total $36; identified differences total $14; missing-source billed amount is $8. Thus 58 = 36 + 14 + 8. The missing-source row has no computed expected amount or variance; it is not assumed to be an overcharge.

The $14 disputed, $2 approved and $2 posted stages are cumulative workflow measures, not amounts to add. The posted value is a synthetic ledger assumption, not independently derived from a payment system. Credit event E3 has negative units and an expected/billed amount of -$10. The duplicate has expected incremental charge zero. Effective dates are inclusive from_date and exclusive until_date; the February 1 event uses v2.

## Reproduce and inspect
Download reproduce.py, invoices.csv, events.csv, rules.csv and expected.json into one directory. Run `python3 reproduce.py`. The script checks expected totals and boundary/duplicate/missing/credit cases, then writes results.json/results.csv. Repeating the run replaces deterministic output; it never creates financial transactions. Expected.json is a manually specified test oracle.

## Limits before production
This narrow fixture uses USD integer amounts, a single service and one rule per period. Production work would need currency/rounding policy, rule overlap/missing-rule validation, independent source completeness checks, permissions, actual approvals/postings, and tests at scale. Matching an invoice line is not proof of service delivery. No match-rate accuracy or savings claim is made.
